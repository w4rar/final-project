<?php
    require_once 'connection.php';
    session_start();
    if (!isset($_SESSION["user"])){
        $_SESSION["email"] = "";
    }

    //search bar code
    if(isset($_POST["search-btn"]) && !empty($_POST["search-products"])) {
        $search = $_POST["search-products"];
        $sql = "SELECT * FROM product WHERE product_name = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $search);
        $stmt->execute();
        $result = $stmt->get_result();
    }
    else{
        $sql = "SELECT * FROM product";
        $result = $conn->query($sql);
    }

    $products = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    } else {
        $message = "No products found.";
    }


    $sqlLimited = "SELECT * FROM product";
    $limited_product = $conn->query($sqlLimited);

    $sqlArrival = "SELECT * FROM arrival";
    $arrival_product = $conn->query($sqlArrival);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anime Haven Shop</title>
    <link rel="stylesheet" href="styles/general.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jaro:opsz@6..72&display=swap" rel="stylesheet">
</head>
<body>
<div class="main">
        <div id="heretop" class="header-one">
            <div class="left">
                    <i class="fa-solid fa-truck"></i>
                    <div class="text">
                        <h5>Fast shipping on all orders</h5>
                        <p>Exclusive offer</p>
                    </div>
            </div>
                
            <span style="background-image:linear-gradient(rgba(255,255,255,0),#FFFFFF,#FFFFFF,rgba(255,255,255,0))"></span>

            <div class="center">
                    <i class="fa-solid fa-boxes-packing"></i>
                    <div class="text">
                        <h5>Free returns</h5>
                        <p>Up to 30 days *</p>
                    </div>
            </div>

            <span style="background-image:linear-gradient(rgba(255,255,255,0),#FFFFFF,#FFFFFF,rgba(255,255,255,0))"></span>

            <div class="right">
                    <i class="fa-solid fa-mobile-screen"></i>
                    <div class="text">
                        <h5>Get the Anime Haven App</h5>
                    </div>
            </div>
        </div>

        <div class="home-section">
            <div class="nav-section">
                <div class="left">
                    <div class="nav-logo">
                        <img src="images/animehaven_logo.png" alt="Anime Haven">
                    </div>
        
                    <div class="nav-links">
                        <a class="css-links" href="homepage.php">Home</a>
                        <a class="css-links" href="#">Shop</a>
                        <a class="css-links" href="#">Limited-Time-Sales</a>
                        <a class="css-links" href="#">New Arrivals</a>
                        <a class="css-links" href="#">Anime</a>
                        <!--For Admin-->
                        <?php
                        if($_SESSION["email"] == "admin@gmail.com"):
                        ?>
                        <a href="admin.php" class="css-links">Admin</a>
                        <?php
                        endif;
                        ?>
                    </div>
                </div>

                <div class="right">
                    <form action="" method="post">
                        <div class="search-bar">
                            <input placeholder="Jujutsu Kaisen🔥" id="search" class="search" type="text" name="search-products">
                            <input class="search-btn" type="submit" value="" name="search-btn">
                        </div>
                    </form>
                    <div class="cart">
                        <a href="#"><i class="fa-solid fa-cart-shopping"></i></a>
                    </div>
                    
                    <div class="nav-users">
                        <?php
                        if (isset($_SESSION["user"])):
                        ?>
                            <a class="btn-login" href="logout.php">Logout</a>
                        <?php
                        else:
                        ?>
                            <a class="btn-login" href="login.php">Login</a>
                            <a class="btn-signup" href="registration.php">Signup</a>
                        <?php
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>

    <?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    
    <?php if (!empty($products)): ?>
        <div class="limited-product-container">
        <?php foreach ($products as $product): ?>
            <div class="card">
                <div class="image">
                    <img src="<?php echo htmlspecialchars($product['product_image']); ?>">
                    <button class="btn-cart"><i class="fa-solid fa-cart-plus"></i> Add to cart</button>
                </div>
                <div class="details">
                    <h3 class="product-name"><strong><?php echo htmlspecialchars($product['product_name']); ?></strong><br></h3>
                    <div class="price-rating">
                        <div class="prices">
                            <p class="price"><strong>$<?php echo number_format($product['price'], 2); ?></strong></p>
                            <p class="discount-price">$<?php echo number_format($product['discount'], 2); ?></strong></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
            <p>no product available</p>
        <?php endif; ?>
    </div>
</body>
</html>