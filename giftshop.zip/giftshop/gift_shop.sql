-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2024 at 06:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gift_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `anime`
--

CREATE TABLE `anime` (
  `anime_id` int(11) NOT NULL,
  `anime_title` varchar(255) NOT NULL,
  `anime_description` text NOT NULL,
  `anime_image` varchar(255) NOT NULL,
  `anime_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `anime`
--

INSERT INTO `anime` (`anime_id`, `anime_title`, `anime_description`, `anime_image`, `anime_link`) VALUES
(1, 'One Piece', 'Embark on a voyage of a lifetime with One Piece. The epic anime series created by renowned mangaka Eiichiro Oda is a global phenomenon, captivating the hearts of fans across generations throughout its 25-year span. This thrilling high seas adventure is filled with unwavering friendship, epic battles for freedom, and the relentless pursuit of dreams. Join Monkey D. Luffy and his lovable pirate crew as they discover the true meaning of power and justice in this great pirate era.', 'animepics/one-piece.jpg', 'https://www.crunchyroll.com/series/GRMG8ZQZR/one-piece'),
(2, 'Horimiya', 'When the popular Hori and the gloomy Miyamura meet, they reveal another side of themselves. Could this be the start of something new?', 'animepics/horimiya.jpg', 'https://www.crunchyroll.com/series/G9VHN9P43/horimiya'),
(3, 'Attack on Titan', 'Known in Japan as Shingeki no Kyojin, many years ago, the last remnants of humanity were forced to retreat behind the towering walls of a fortified city to escape the massive, man-eating Titans that roamed the land outside their fortress. Only the heroic members of the Scouting Legion dared to stray beyond the safety of the walls – but even those brave warriors seldom returned alive. Those within the city clung to the illusion of a peaceful existence until the day that dream was shattered, and their slim chance at survival was reduced to one horrifying choice: kill – or be devoured!', 'animepics/attack-on-titan.jpg', 'https://www.crunchyroll.com/series/GR751KNZY/attack-on-titan'),
(4, 'Jujutsu Kaisen', 'Follow young Yuji Itadori in this dark supernatural action series as he begins training in the dangerous arts of jujutsu sorcery and explores the violent world of curses! Yuji Itadori eats a cursed finger to save a classmate, and now Ryomen Sukuna, a powerfully evil sorcerer known as the King of Curses, lives in Itadori’s soul. Curses are supernatural terrors created from negative human emotions. This cursed energy can be used as a power source by jujutsu sorcerers and cursed spirits alike.', 'animepics/jujutsu-kaisen.jpg', 'https://www.crunchyroll.com/series/GRDV0019R/jujutsu-kaisen'),
(5, 'Demon Slayer: Kimetsu no Yaiba', 'It is the Taisho Period in Japan. Tanjiro, a kindhearted boy who sells charcoal for a living, finds his family slaughtered by a demon. To make matters worse, his younger sister Nezuko, the sole survivor, has been transformed into a demon herself.', 'animepics/demon-slayer.jpg', 'https://www.crunchyroll.com/series/GY5P48XEY/demon-slayer-kimetsu-no-yaiba'),
(6, 'DARLING in the FRANXX', 'The distant future: Humanity established the mobile fort city, Plantation, upon the ruined wasteland. Within the city were pilot quarters, Mistilteinn, otherwise known as the “Birdcage.” That is where the children live... Their only mission in life was the fight. Their enemies are the mysterious giant organisms known as Kyoryu. The children operate robots known as FRANXX in order to face these still unseen enemies. Among them was a boy who was once called a child prodigy: Code number 016, Hiro. One day, a mysterious girl called Zero Two appears in front of Hiro. “I’ve found you, my Darling.”', 'animepics/franxx.jpg', 'https://www.crunchyroll.com/series/GY8VEQ95Y/darling-in-the-franxx'),
(7, 'Naruto Shippuden', 'Naruto Uzumaki wants to be the best ninja in the land. He\'s done well so far, but with the looming danger posed by the mysterious Akatsuki organization, Naruto knows he must train harder than ever and leaves his village for intense exercises that will push him to his limits.', 'animepics/naruto.jpg', 'https://www.crunchyroll.com/series/GYQ4MW246/naruto-shippuden');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `product_type` varchar(50) DEFAULT NULL,
  `product_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `image`, `quantity`, `product_type`, `product_description`) VALUES
(110, 5, 'One Piece Boa Hancock Fabric Cloth Banner', 1700, 'shopProducts/boa hancock.jpg', 1, 'arrival', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.'),
(111, 5, 'One Piece Ace Printed T-Shirt', 300, 'shopProducts/ace printed t shirt.jpg', 1, 'limited', 'A High Quality Printed T-Shirt One Piece Ace'),
(112, 5, 'Yuki Tsukumo T-shirt Jujutsu Kaisen', 640, 'shopProducts/yuki tshirt.jpg', 1, 'limited', 'Yuki Tsukumo T-shirt kenjaku Choso jujutsu kaisen Horror Anime Shirt All Size The 100% cotton men\'s classic tee will help you land a more structured look'),
(113, 5, 'Franky Banner Fabric Cloth', 1900, 'shopProducts/franky banner cloth fabric.jpg', 1, 'limited', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.'),
(117, 4, 'Yuki Tsukumo T-shirt Jujutsu Kaisen', 640, 'shopProducts/yuki tshirt.jpg', 2, 'limited', 'Yuki Tsukumo T-shirt kenjaku Choso jujutsu kaisen Horror Anime Shirt All Size The 100% cotton men\'s classic tee will help you land a more structured look'),
(118, 4, 'Darling in the Franxx Anime Accessories Bracelet', 780, 'shopProducts/Darling in the Franxx.jpg', 1, 'limited', 'From the anime Darling in the Franxx Anime Accessories Bracelet'),
(119, 4, 'Germa Sanji Fabric Cloth', 2000, 'shopProducts/germasanji.jpg', 1, 'limited', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal_code` varchar(50) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `grand_total` varchar(50) NOT NULL,
  `pmode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `name`, `email`, `address`, `country`, `city`, `postal_code`, `phone_number`, `grand_total`, `pmode`) VALUES
(20241125, 'Anthony', 'user123@gmail.com', '123', 'iyfg', 'phil', '1832', '09739472141', '4060', 'Cash On Delivery'),
(20241126, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '610', 'Cash On Delivery'),
(20241127, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '610', 'Cash On Delivery'),
(20241128, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '610', 'Cash On Delivery'),
(20241129, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241130, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'Cash On Delivery'),
(20241131, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'Cash On Delivery'),
(20241132, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1900', 'Cash On Delivery'),
(20241133, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '11800', 'Cash On Delivery'),
(20241134, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '420', 'Cash On Delivery'),
(20241135, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '610', 'Cash On Delivery'),
(20241136, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'Cash On Delivery'),
(20241137, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241138, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '4000', 'Cash On Delivery'),
(20241139, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'Cash On Delivery'),
(20241140, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'Cash On Delivery'),
(20241141, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241142, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3600', 'Cash On Delivery'),
(20241143, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241144, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241145, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241146, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241147, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241148, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241149, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241150, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241151, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241152, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241153, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241154, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241155, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241156, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241157, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241158, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241159, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241160, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'Cash On Delivery'),
(20241161, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241162, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '13600', 'Cash On Delivery'),
(20241163, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241164, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241165, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241166, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241167, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241168, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3600', 'Cash On Delivery'),
(20241169, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241170, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241171, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241172, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1030', 'Cash On Delivery'),
(20241173, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241174, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5900', 'Cash On Delivery'),
(20241175, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241176, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241177, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241178, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241179, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241180, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241181, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241182, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241183, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '4470', 'Cash On Delivery'),
(20241184, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241185, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241186, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'Credit Card'),
(20241187, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'Cash On Delivery'),
(20241188, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'Cash On Delivery'),
(20241189, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '350', 'COD'),
(20241190, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'COD'),
(20241191, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'COD'),
(20241192, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'COD'),
(20241193, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'COD'),
(20241194, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'COD'),
(20241195, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'COD'),
(20241196, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1900', 'COD'),
(20241197, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1900', 'COD'),
(20241198, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1900', 'COD'),
(20241199, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '1900', 'CreditCard'),
(20241200, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'COD'),
(20241201, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3700', 'COD'),
(20241202, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3600', 'COD'),
(20241203, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'COD'),
(20241204, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '2000', 'COD'),
(20241205, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '6000', 'COD'),
(20241206, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'COD'),
(20241207, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '5600', 'COD'),
(20241208, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '3900', 'COD'),
(20241209, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '0', 'COD'),
(20241210, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '10250', 'COD'),
(20241211, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '10000', 'COD'),
(20241212, 'arwin', 'arwin@gmail.com', 'baras', 'philippines', 'rizal', '1970', '911', '11900', 'COD');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `category` varchar(50) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`product_id`, `product_name`, `product_description`, `price`, `discount`, `quantity`, `category`, `product_image`) VALUES
(20241100, 'One Piece Boa Hancock Fabric Cloth Banner', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 1700, 2500, 1, 'arrival', 'shopProducts/boa hancock.jpg'),
(20241101, 'Franky Banner Fabric Cloth', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 1900, 2700, 1, 'arrival', 'shopProducts/franky banner cloth fabric.jpg'),
(20241102, 'Germa Sanji Fabric Cloth', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 2000, 2900, 1, 'arrival', 'shopProducts/germasanji.jpg'),
(20241103, 'Luffy Gear 5th Fabric Cloth Banner', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 2000, 2500, 1, 'arrival', 'shopProducts/luffy gear5th.jpg'),
(20241104, 'Trafalgar Law Fabric Cloth Banner', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 2000, 2900, 1, 'arrival', 'shopProducts/trafalgar law.jpg'),
(20241105, 'Zoro Asura Fabric Cloth Banner', 'It’s a perfect on-display merch for gamers and anime lovers to express their passion.', 2000, 2900, 1, 'arrival', 'shopProducts/zoroasura.jpg'),
(20241106, 'One Piece Ace Printed T-Shirt', 'A High Quality Printed T-Shirt One Piece Ace', 300, 400, 1, 'limited', 'shopProducts/ace printed t shirt.jpg'),
(20241107, 'Attack on Titan Eren Yeager Printed T-Shirt', 'A High Quality Printed T-Shirt Attack on Titan Eren Yeager', 350, 480, 1, 'limited', 'shopProducts/eren printed.jpg'),
(20241108, 'Jujutsu Kaisen Gojo Hooded Neck', 'Quality Cotton Fleece Material, Smooth and soft adem material, Comfortable adem wear, Anime Model', 610, 800, 1, 'limited', 'shopProducts/Gojo Hooded Neck.jpg'),
(20241109, 'Hori San To Miyamura T-shirt - Kawaii Japanese Anime Horimiya Printed T- shirt', 'Our merchandise will deliver you satisfaction with a clear, vivid, correct shade for excellent completed clothes.', 420, 500, 1, 'limited', 'shopProducts/horimiya.jpg'),
(20241110, 'Jujutsu Kaisen Key Chains', 'High Quality: Made from durable PVC. Versatile: Great for backpacks, purses, or even as a decorative piece. Perfect Gift: A great gift for friends and family who love anime.', 200, 400, 1, 'limited', 'shopProducts/jjkkeychain.jpg'),
(20241111, '5 Pack Demon Slayer Anime Figures', 'Inspired by popular animation. With unique design and perfect details, it is very suitable for any fan of this anime.', 2794, 3000, 1, 'figures', 'shopProducts/5 Pack Demon Slayer Action Figures.webp'),
(20241112, 'Darling in the Franxx Anime Accessories Bracelet', 'From the anime Darling in the Franxx Anime Accessories Bracelet', 780, 1200, 1, 'accessories', 'shopProducts/Darling in the Franxx.jpg'),
(20241113, 'Nezuko Plushie Toy Demon Slayer', 'Anime Plush Toys, best gift for any Anime fan. It can be used as decoration, collectibles, hug pillows, etc. Filled with 100% cotton, made of soft plush and high-quality PP cotton.', 1175, 1800, 1, 'plush', 'shopProducts/Nezuko Plushie Demon Slayer.jpg'),
(20241114, 'Yuki Tsukumo T-shirt Jujutsu Kaisen', 'Yuki Tsukumo T-shirt kenjaku Choso jujutsu kaisen Horror Anime Shirt All Size The 100% cotton men\'s classic tee will help you land a more structured look', 640, 1000, 1, 'shirt', 'shopProducts/yuki tshirt.jpg'),
(20241115, 'Unisex Oversize Naruto Uchiha Sasuke, Itachi, Obito Anime Hoodie', 'Top Quality Naruto Hoodie', 900, 1200, 1, 'hoodie', 'shopProducts/Uchiha Sasuke.jpg'),
(20241116, '3D Illusion Night Lamp Jujutsu Kaisen', 'Anime Jujutsu Kaisen Satoru Gojo lamp, 3D illusion night lamp made of plane acrylic glass', 2080, 3100, 1, 'decor', 'shopProducts/3D Illusion Night Lamp Jujutsu Kaisen Gojo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(4, 'user123', 'user123@gmail.com', '$2y$10$SMtsKUAdbvyPXxG5ef/riuQIwZ7gj76TL.1FZaQHELimLFySJDulu'),
(5, 'hades', 'hades123@gmail.com', '$2y$10$F2takpoSAmT/UIWq.UF7/.K2grP8v9HHTiNJjUehGFrnNFV47zvey'),
(202400, 'win', 'arwin@gmail.com', '$2y$10$pCi6lnBrvhsyfhn.FzVaYeEU6NiMU3wBhq.X0nDfG/OTuoiDTw5Li');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anime`
--
ALTER TABLE `anime`
  ADD PRIMARY KEY (`anime_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anime`
--
ALTER TABLE `anime`
  MODIFY `anime_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=228;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20241213;

--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20241117;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202401;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
